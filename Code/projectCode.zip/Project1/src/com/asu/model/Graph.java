package com.asu.model;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Graph {

	/** The adj list. */
	private Map<Integer, List<Integer>> adjList;

	/**
	 * Instantiates a new plot graph.
	 *
	 * @param vertices
	 *            the vertices
	 */
	public Graph(int vertices) {
		adjList = new HashMap<Integer, List<Integer>>();
		for (int i = 1; i <= vertices; i++) {
			adjList.put(i, new LinkedList<Integer>());
		}
	}

	/**
	 * Adds the edge.
	 *
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 */
	public void addEdge(int start, int end) {
		if (start <= adjList.size() && end <= adjList.size()) {
			List<Integer> list1 = adjList.get(start);
			list1.add(end);
			List<Integer> list2 = adjList.get(end);
			list2.add(start);
		}
	}

	public Map<Integer, List<Integer>> getAdjList() {
		return adjList;
	}

}
