package com.asu.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class BFS {
	
	private Queue<Integer> queue;
	
	public BFS() {
		queue = new LinkedList<Integer>();
	}
	
	public int bfs(Map<Integer, List<Integer>> adjList, int source, int destination) {
		int numOfNodes = adjList.size() - 1;
		int[] visited = new int[numOfNodes + 1];
		int[] dist = new int[numOfNodes + 1];
		int element;
		visited[source-1] = 1;
		dist[source-1] = 0;
		queue.add(source);
		while(!queue.isEmpty()) {
			element = queue.remove();
			List<Integer> adjacentElem = adjList.get(element);
				for (Integer w: adjacentElem) {
					if (visited[w-1] == 0) {
						visited[w-1] = 1;
						queue.add(w);
						dist[w-1] = dist[element-1] + 1;
					}
				}
		}
		return dist[destination - 1];
	}

}
