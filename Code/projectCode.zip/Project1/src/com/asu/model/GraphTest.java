package com.asu.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class GraphTest {
	
	public static final String PATH = "path";
	public static final String PROP_FILE = "config.properties";
	public static final String COEF_RELATION = "r";

	public static void main(String[] args) {
		Properties prop = new Properties();
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(PROP_FILE);
			prop.load(inputStream);
			String filePath = prop.getProperty(PATH);
			float coefRel = Float.parseFloat(prop.getProperty(COEF_RELATION));
			ReadFiles readFiles = new ReadFiles(new File(filePath));
			Thread job1 = new Thread(readFiles);
			job1.start();
			while (job1.isAlive()) {
			}
			DegreeDistribution degree = new DegreeDistribution();
			List<float[]> dataSet = readFiles.getNewList();
			Graph graph = new Graph(dataSet.size());
			PlotGraph.plot(dataSet, graph, coefRel);
			Map<Integer, List<Integer>> map = graph.getAdjList();
			List<Integer> degrees = degree.degDist(map);
			Map<Integer, Integer> data = degree.histogram(degrees);
			for (Map.Entry<Integer, Integer> entry : data.entrySet()) {
				System.out.println(entry.getKey() + "-->" + " "
						+ entry.getValue());
				System.out.println();
			}
			System.out.println();
			List<Integer> superNodes = degree.getSuperNodes(degrees);
			System.out.println("supernodes: " + superNodes);
			float[] clustCoefOfVert = GraphUtil.computeClusterCoef(map);
			float graphCoef = GraphUtil.graphClusterCoef(clustCoefOfVert);
			System.out.println("clustering coef:  " + graphCoef);
			float meanVertexDeg = degree.getAverageDegree(degrees);
			System.out.println("mean Vertex degree: " + meanVertexDeg);
			float randomClusCoef = meanVertexDeg / map.size();
			double randomPathLength = Math.log10(map.size())
					/ Math.log10(meanVertexDeg);
			System.out.println("random clustring coef: " + randomClusCoef);
			System.out.println("RandomPath length: " + randomPathLength);
			float pathLength = GraphUtil
					.getPathLength(GraphUtil.distances(map));
			System.out.println("Path length of a graph: " + pathLength);
		} catch (IOException ioExp) {
			System.out.println("Exception while reading property file." + ioExp);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException ioExp) {
					System.out.println("Exception while closing input Stream. "
							+ ioExp);
				}
			}
		}

	}
}
