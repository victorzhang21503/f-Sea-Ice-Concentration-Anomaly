package com.asu.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The Class ReadFiles.
 */
public class ReadFiles implements Runnable {

	private List<float[]> list_of_data = new ArrayList<float[]>();
	private List<float[]> newList = new ArrayList<float[]>();
	private List<File> totalFiles = new ArrayList<File>();
	private static int nextFile = -1;
	private ExecutorService executorService;
	File file;

	public ReadFiles(File file) {
		this.file = file;
	}

	/**
	 * Load data.
	 *
	 * @param myFile
	 *            the my file
	 * @return the map
	 */
	public void loadData() {
		float[] elements;
		FileInputStream fis = null;
		// read the file into a byte array
		try {
			while (nextFile < 468) {
				File file = getNextFile();
					if (file != null) {
						synchronized (file) {
							elements = new float[66129];
							fis = new FileInputStream(file);
							byte[] arr = new byte[(int) file.length()];
							fis.read(arr);
							// create a byte buffer and wrap the array
							ByteBuffer bb = ByteBuffer.wrap(arr);

							// (big endian, Java's native) format,
							// then set the byte order of the ByteBuffer
							// if(use_little_endian)
							bb.order(ByteOrder.LITTLE_ENDIAN);

							// read your integers using ByteBuffer's getFloat().
							// four bytes converted into an float!
							// int value = 0;
							while (bb.hasRemaining()) {
								for (int k = 0, l = 0; k < arr.length / 4; k++) {
									float value = bb.getFloat();
									if (value == 157 || value == 168) {
										continue;
									}
									elements[l] = value;
									l++;
								}
							}
							list_of_data.add(elements);
						}
					}
			}
		} catch (FileNotFoundException fnf) {
			System.out.println("File not found Exception." + fnf);;
		} catch (IOException ioExp) {
			System.out.println("Exception while reading files." + ioExp);
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException ioExp) {
					System.out.println("Exception while closing input stream." + ioExp);
				}
			}
		}
	}

	public void run() {
		getAllFiles(file);
		Runnable job2 = new Runnable() {

			public void run() {
				loadData();

			}
		};
		executorService = Executors.newFixedThreadPool(totalFiles.size());
		executorService.execute(job2);
		executorService.shutdown();
		while (!executorService.isTerminated()) {
		}
		addToList(list_of_data);
	}

	/**
	 * Gets the next file.
	 *
	 * @return the next file
	 */
	private synchronized File getNextFile() {
		nextFile++;
		if (nextFile < totalFiles.size()) {
			return totalFiles.get(nextFile);
		} else {
			return null;
		}
	}

	/**
	 * Gets the all files.
	 *
	 * @param fileorfolder
	 *            the fileorfolder
	 * @return the all files
	 */
	private void getAllFiles(File fileorfolder) {
		if (fileorfolder.isDirectory()) {
			for (File folders : fileorfolder.listFiles()) {
				if (folders.isDirectory()) {
					for (File entry : folders.listFiles()) {
						totalFiles.add(entry);
					}
				}
			}
		}
	}

	/**
	 * Adds the to list.
	 *
	 * @param totalList
	 *            the total list
	 */
	private void addToList(List<float[]> totalList) {
		float[] elements1;
		for (int i = 0; i < 66129; i++) {
			int j = 0;
			elements1 = new float[totalList.size()];
			for (float[] list : totalList) {
				elements1[j] = list[i];
				j++;
			}
			newList.add(elements1);
		}
	}

	/**
	 * Gets the map.
	 *
	 * @return the map
	 */
	public Map<Integer, double[]> getMap() {
		return null;
	}

	/**
	 * Gets the new list.
	 *
	 * @return the new list
	 */
	public List<float[]> getNewList() {
		return newList;
	}
}
