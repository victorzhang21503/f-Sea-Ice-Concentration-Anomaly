package com.asu.model;

import java.util.List;

public class PlotGraph {
	
	
	/**
	 * Plot.
	 *
	 * @param dataSet
	 *            the data set
	 * @param graph
	 *            the graph
	 */
	public static void plot(List<float[]> dataSet, Graph graph, float coefRel) {
		float r = 0;
		float[] mean = GraphUtil.getMean(dataSet);
		float[] sxxArray = GraphUtil.getSxxArray(dataSet, mean);
		for (int i = 0; i < dataSet.size() - 1; i++) {
			if (sxxArray[i] != 0) {
				for (int j = i + 1; j < dataSet.size(); j++) {
					if (sxxArray[j] != 0) {
						r = coefRelation(dataSet.get(i), dataSet.get(j), mean[i], mean[j], sxxArray[i], sxxArray[j]);
						if (r > coefRel) {
							graph.addEdge(i+1, j+1);
						}
					}
				}
			}
		}
	}

	/**
	 * Coef relation.
	 *
	 * @param u
	 *            the u
	 * @param v
	 *            the v
	 * @return the float
	 */
	private static float coefRelation(float[] u, float[] v, float meanU, float meanV, float sxx, float syy) {
			float sxy = GraphUtil.calculate4LagSxy(u, v, meanU, meanV);
			return (Math.abs(sxy / (float)(Math.sqrt(sxx * syy))));	
	}
}
