package com.asu.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DegreeDistribution {
	
	public List<Integer> degDist(Map<Integer, List<Integer>> map) {
		List<Integer> degOfElement = new ArrayList<Integer>();
		for (Map.Entry<Integer, List<Integer>> entry : map.entrySet()) {
			degOfElement.add(entry.getValue().size());
		}
		return degOfElement;
	}

	public Map<Integer, Integer> histogram(List<Integer> degrees) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (Integer i : degrees) {
			Integer count = map.get(i);
			map.put(i, (count == null) ? 1 : count + 1);
		}
		return map;
	}

	public List<Integer> getSuperNodes(List<Integer> degrees) {
		List<Integer> superNodes = new ArrayList<Integer>();
		float avgDegree = getAverageDegree(degrees);
		for (int i = 0; i < degrees.size(); i++) {
			if (degrees.get(i) > avgDegree) {
				superNodes.add(i + 1);
			}
		}
		return superNodes;
	}
	
	public float getAverageDegree(List<Integer> degrees) {
		float sum = 0;
		for (Integer i : degrees) {
			sum += i;
		}
		return sum / degrees.size();
	}
}
