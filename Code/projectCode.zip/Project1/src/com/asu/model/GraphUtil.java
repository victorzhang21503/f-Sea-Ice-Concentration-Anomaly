package com.asu.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Class GraphUtil.
 */
public class GraphUtil {

	/**
	 * Gets the mean.
	 *
	 * @param list
	 *            the list
	 * @return the mean
	 */
	public static float[] getMean(List<float[]> list) {
		float[] mean = new float[list.size()];
		float sum;
		for (int i = 0; i < list.size(); i++) {
			sum = 0f;
			float[] element = list.get(i);
			for(int j = 0; j < element.length; j++) {
				sum += element[j];
			}
			mean[i] = sum / element.length;
		}
		return mean;
	}

	
	/**
	 * Gets the sxx array.
	 *
	 * @param list
	 *            the list
	 * @param mean
	 *            the mean
	 * @return the sxx array
	 */
	public static float[] getSxxArray(List<float[]> list, float[] mean) {
		float[] sxxArray = new float[list.size()];
		float sum;
		for (int i = 0; i < list.size(); i++) {
			sum = 0f;
			float[] element = list.get(i);
			for(int j = 0; j < element.length; j++) {
				sum += Math.pow((element[j] - mean[i]), 2);
			}
			sxxArray[i] = sum;
		}
		return sxxArray;
	}


	/**
	 * Calculate sxy.
	 *
	 * @param u the u
	 * @param v the v
	 * @param meanU the mean u
	 * @param meanV the mean v
	 * @return the float
	 */
	public static float calculateSxy(float[] u, float[] v, float meanU,
			float meanV) {
		int size = u.length;
		float sum = 0;
		for (int i = 0; i < size; i++) {
			sum += ((u[i] - meanU) * (v[i] - meanV));
		}
		return sum;
	}
	
	/**
	 * Calculate sxy.
	 *
	 * @param u the u
	 * @param v the v
	 * @param meanU the mean u
	 * @param meanV the mean v
	 * @return the float
	 */
	public static float calculate1LagSxy(float[] u, float[] v, float meanU,
			float meanV) {
		int size = u.length;
		float sum = 0;
		for (int i = 0; i < size-1; i++) {
			sum += ((u[i] - meanU) * (v[i+1] - meanV));
		}
		return sum;
	}
	
	/**
	 * Calculate sxy.
	 *
	 * @param u the u
	 * @param v the v
	 * @param meanU the mean u
	 * @param meanV the mean v
	 * @return the float
	 */
	public static float calculate2LagSxy(float[] u, float[] v, float meanU,
			float meanV) {
		int size = u.length;
		float sum = 0;
		for (int i = 0; i < size-2; i++) {
			sum += ((u[i] - meanU) * (v[i+2] - meanV));
		}
		return sum;
	}
	
	/**
	 * Calculate sxy.
	 *
	 * @param u the u
	 * @param v the v
	 * @param meanU the mean u
	 * @param meanV the mean v
	 * @return the float
	 */
	public static float calculate3LagSxy(float[] u, float[] v, float meanU,
			float meanV) {
		int size = u.length;
		float sum = 0;
		for (int i = 0; i < size-3; i++) {
			sum += ((u[i] - meanU) * (v[i+3] - meanV));
		}
		return sum;
	}
	
	/**
	 * Calculate sxy.
	 *
	 * @param u the u
	 * @param v the v
	 * @param meanU the mean u
	 * @param meanV the mean v
	 * @return the float
	 */
	public static float calculate4LagSxy(float[] u, float[] v, float meanU,
			float meanV) {
		int size = u.length;
		float sum = 0;
		for (int i = 0; i < size-4; i++) {
			sum += ((u[i] - meanU) * (v[i+4] - meanV));
		}
		return sum;
	}

	
	/**
	 * Compute cluster coef.
	 *
	 * @param map
	 *            the map
	 * @return the float[]
	 */
	public static float[] computeClusterCoef(Map<Integer, List<Integer>> map) {
		int vertices;
		int edges;
		int totalVertices;
		float[] clusterCoef = new float[map.size()];
		int l = 0;
		for (Map.Entry<Integer, List<Integer>> entry : map.entrySet()) {
			List<Integer> adVertices = entry.getValue();
			vertices = adVertices.size();
			totalVertices = vertices + 1;
			edges = vertices;
			if (totalVertices > 1) {
				for(int i = 0; i < vertices-1; i++) {
					List<Integer> element = map.get(adVertices.get(i));
					for(int j = i+1; j < vertices; j++) {
						if (element.contains(adVertices.get(j))) {
							edges = edges + 1;
						}
					}
				}
				clusterCoef[l] = (float)(2*edges)/(totalVertices * (totalVertices -1));
			} else {
				clusterCoef[l] = 0;
			}
			l++;
		}
		return clusterCoef;
	}

	/**
	 * Graph cluster coef.
	 *
	 * @param clustCoefOfVert
	 *            the clust coef of vert
	 * @return the float
	 */
	public static float graphClusterCoef(float[] clustCoefOfVert) {
		int size = clustCoefOfVert.length;
		float sum = 0;
		for( int i = 0; i < size; i++) {
			sum += clustCoefOfVert[i];
		}
		return sum / size;
	}
	
	/**
	 * Distances.
	 *
	 * @param map
	 *            the map
	 * @return the list
	 */
	public static List<Integer> distances(Map<Integer, List<Integer>> map) {
		BFS search = new BFS();
		List<Integer> dist = new ArrayList<Integer>();
		for (int i =0; i < map.size() - 1; i++) {
			for (int j =i + 1; j < map.size(); j++) {
				if (map.get(i+1).contains(j+1)) {
					dist.add(1);
				} else {
					dist.add(search.bfs(map, i+1, j+1));
				}
			}
		}
		return dist;
	}
	
	/**
	 * Gets the path length.
	 *
	 * @param distances
	 *            the distances
	 * @return the path length
	 */
	public static float getPathLength(List<Integer> distances) {
		float sum = 0;
		for(Integer dist: distances) {
			sum += dist;
		}
		return sum / distances.size();
	}
}
